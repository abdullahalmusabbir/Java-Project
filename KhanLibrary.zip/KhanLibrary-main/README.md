<h1 align="center">Khan Library</h1>

JavaFX GUI project
