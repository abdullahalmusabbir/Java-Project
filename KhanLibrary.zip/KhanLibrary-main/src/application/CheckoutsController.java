package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class CheckoutsController {

   @FXML
   private TextField itemIDField, memberIDField;

   @FXML
   private TextArea textarea;

   @FXML
   void checkSearch(ActionEvent event) {

   }

   @FXML
   void checkin(ActionEvent event) {

   }

   @FXML
   void checkout(ActionEvent event) {

   }

}
